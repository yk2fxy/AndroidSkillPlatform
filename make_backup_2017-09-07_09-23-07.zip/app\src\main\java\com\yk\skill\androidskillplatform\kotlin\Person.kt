package com.yk.skill.androidskillplatform.kotlin

/**
 * Created by Administrator on 2017/8/22.
 */
data class Person(var age:Int,var name:String)
data class Student(var number:String,var name:String)