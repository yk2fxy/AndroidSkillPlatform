package com.yk.skill.androidskillplatform.normal.index;

import android.graphics.drawable.Drawable;

/**
 * Created by yuankang on 2017/8/8.
 */

public class NormalIndexItemBean {
    private Drawable img;
    private String title;
    private String content;

    public Drawable getImg() {
        return img;
    }

    public void setImg(Drawable img) {
        this.img = img;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
